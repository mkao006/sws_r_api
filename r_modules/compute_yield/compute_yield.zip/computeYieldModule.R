## load the library
## require("faosws")

## Set up for the test environment
## if(Sys.getenv("USERNAME") == "kao"){
##     GetTestEnvironment(baseUrl = "https://hqlqasws1.hq.un.fao.org:8181/sws",
##                        token = "6d98803b-e623-43dc-b137-4130f0dc140c")
## }

print(R.version.string)

## Pivot to vectorize yield computation
## newPivot = c(
##     Pivoting(code= "geographicAreaM49", ascending = TRUE),
##     Pivoting(code= "measuredItemCPC", ascending = TRUE),
##     Pivoting(code = "timePointYears", ascending = FALSE),
##     Pivoting(code= "measuredElement", ascending = TRUE)
##     )

## ## Query the data
## query = GetData(
##     key = swsContext.datasets[[1]],
##     flags = TRUE,
##     normalized = FALSE,
##     pivoting = newPivot
## )



## ## write back to the data
## SaveData(domain = "agriculture", dataset = "agriculture", data = query,
##          normalized = FALSE)

## ## Function for computing the yield
## computeYield = function(production, areaHarvested){
##     ifelse(production == 0 | areaHarvested == 0, NA, production/areaHarvested)
## }

## ## Compute the yield
## query[, Value_measuredElement_5421 :=
##       as.numeric(computeYield(Value_measuredElement_5510,
##                               Value_measuredElement_5312))]

## ## Create new flag (Temporary)
## query[, flagProduction_measuredElement_5421 :=
##       as.character(ifelse(is.na(Value_measuredElement_5421), NA, "C"))]

## ## Add the newly computed key back to the dimension
## addKey(swsContext.datasets[[1]]@dimensions[["measuredElement"]]) = "5421"

## ## Create column for comments as required in the API documentation
## query[, comment := "yield computed based on production and area harvested"]

## ## write back to the data
## SaveData(domain = "agriculture", dataset = "agriculture", data = query,
##          normalized = FALSE)
